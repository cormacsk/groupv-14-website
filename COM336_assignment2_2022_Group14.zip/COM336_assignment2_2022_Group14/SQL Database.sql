-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Apr 11, 2022 at 01:43 PM
-- Server version: 5.7.36
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cardb_project`
--
CREATE DATABASE IF NOT EXISTS `cardb_project` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `cardb_project`;

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

DROP TABLE IF EXISTS `branch`;
CREATE TABLE IF NOT EXISTS `branch` (
  `BranchID` int(5) NOT NULL AUTO_INCREMENT,
  `Name` varchar(21) DEFAULT NULL,
  `Location` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`BranchID`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` (`BranchID`, `Name`, `Location`) VALUES
(1, 'Automobile Retailers', 'Derry'),
(2, 'Automobile Retailers', 'Strabane'),
(3, 'Automobile Retailers', 'Limavady'),
(4, 'Automobile Retailers', 'Coleraine');

-- --------------------------------------------------------

--
-- Table structure for table `cars`
--

DROP TABLE IF EXISTS `cars`;
CREATE TABLE IF NOT EXISTS `cars` (
  `CarID` int(5) NOT NULL AUTO_INCREMENT,
  `CarName` varchar(30) DEFAULT NULL,
  `Type` varchar(24) NOT NULL,
  `Year` int(11) DEFAULT NULL,
  `EngineSize` varchar(5) DEFAULT NULL,
  `Doors` int(11) DEFAULT NULL,
  `Price` int(11) DEFAULT NULL,
  `image` varchar(124) NOT NULL,
  PRIMARY KEY (`CarID`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cars`
--

INSERT INTO `cars` (`CarID`, `CarName`, `Type`, `Year`, `EngineSize`, `Doors`, `Price`, `image`) VALUES
(1, 'C-Class', 'Coupe', 2020, '2L', 4, 42000, 'c-class.jpg'),
(2, 'E-Class', 'Coupe', 2016, '1.5L', 4, 25000, 'e-class.jpg'),
(3, 'S-Class', 'Coupe', 2021, '2L', 4, 80000, 's-class.jpg'),
(4, 'GLS', 'SUV', 2018, '1.8L', 4, 73000, 'GLS-SUV.jpg'),
(5, 'V-Class', 'SUV', 2022, '1L', 4, 55000, 'v-class.jpg'),
(6, 'AMG-GT', 'Sport', 2021, '2.6L', 2, 120000, 'amg-gt.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
CREATE TABLE IF NOT EXISTS `customer` (
  `CustomerID` int(5) NOT NULL AUTO_INCREMENT,
  `Name` varchar(21) DEFAULT NULL,
  `Age` int(11) DEFAULT NULL,
  `DateOfBirth` date DEFAULT NULL,
  `Address` varchar(35) DEFAULT NULL,
  `PostCode` varchar(8) DEFAULT NULL,
  `PhoneNo` varchar(124) DEFAULT NULL,
  `Password` varchar(18) NOT NULL,
  PRIMARY KEY (`CustomerID`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`CustomerID`, `Name`, `Age`, `DateOfBirth`, `Address`, `PostCode`, `PhoneNo`, `Password`) VALUES
(1, 'Dean Doherty', 23, '1999-02-18', '12 Maureen Avenue', 'BT48 6TE', '735827452', 'Password123'),
(2, 'Louise Gee', 45, '1976-12-12', '562 Melrose Lane', 'BT48 6KA', '738326157', 'Password123'),
(3, 'Hannah Logue', 27, '1994-07-24', '21 Bishop Street', 'BT48 2SG', '782895993', 'Password123'),
(4, 'Richard Yore', 59, '1963-01-09', '462 Bridge Park', 'BT47 4TP', '789522157', 'Password123'),
(5, 'John Bell', 30, '1993-09-11', '36 Sherman Court', 'BT48 6TB', '754217984', 'Password123'),
(6, 'Riley Parke', 29, '1993-02-28', '17 Galliagh Road', 'BT48 8LN', '738472847', 'Password123'),
(8, 'Amy Waller', 22, '2000-02-08', '14 Ardnamoyle Park', 'BT48 8HM', '730256142', 'Password123'),
(9, 'Jack Hegarty', 20, '2001-10-12', '43 Ardnamoyle Park', 'BT48 8HN', '7935509095', 'password123');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `OrderID` int(5) NOT NULL AUTO_INCREMENT,
  `CustomerID` int(5) DEFAULT NULL,
  `CarID` int(5) DEFAULT NULL,
  `Quantity` int(11) DEFAULT NULL,
  PRIMARY KEY (`OrderID`),
  KEY `CarID` (`CarID`),
  KEY `CustomerID` (`CustomerID`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`OrderID`, `CustomerID`, `CarID`, `Quantity`) VALUES
(1, 5, 2, 1),
(2, 1, 5, 1),
(3, 4, 1, 1),
(4, 6, 3, 1),
(5, 2, 6, 1),
(6, 3, 4, 1),
(9, 9, 5, 1);

-- --------------------------------------------------------

--
-- Table structure for table `review`
--

DROP TABLE IF EXISTS `review`;
CREATE TABLE IF NOT EXISTS `review` (
  `ReviewID` int(5) NOT NULL AUTO_INCREMENT,
  `CustomerID` int(5) DEFAULT NULL,
  `CarID` int(5) NOT NULL,
  `Rating` int(1) NOT NULL,
  `Comment` varchar(355) DEFAULT NULL,
  PRIMARY KEY (`ReviewID`),
  KEY `CustomerID` (`CustomerID`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `review`
--

INSERT INTO `review` (`ReviewID`, `CustomerID`, `CarID`, `Rating`, `Comment`) VALUES
(1, 1, 1, 4, 'Great customer service and model to drive. '),
(3, 3, 1, 5, 'Great experience, would recommend.'),
(4, 4, 2, 4, 'Would definitely recommend to others looking for a new car.'),
(2, 2, 3, 3, 'Quick and easy process buying my new car. However upon further usage it does not as well as expected'),
(5, 5, 5, 1, 'Poor communication when ordering and car was not what was advertised.'),
(6, 6, 4, 3, 'Vehicle was great to drive but was difficult ordering and sometimes communicating with the service.'),
(7, 8, 6, 2, 'Vehicle was good to drive in but was in poor condition when I recieved it.');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

DROP TABLE IF EXISTS `staff`;
CREATE TABLE IF NOT EXISTS `staff` (
  `StaffID` int(5) NOT NULL AUTO_INCREMENT,
  `Name` varchar(21) DEFAULT NULL,
  `Age` int(11) DEFAULT NULL,
  `DateOfBirth` date DEFAULT NULL,
  `Address` varchar(35) DEFAULT NULL,
  `PostCode` varchar(8) DEFAULT NULL,
  `PhoneNo` int(11) DEFAULT NULL,
  `BranchID` int(5) DEFAULT NULL,
  PRIMARY KEY (`StaffID`),
  KEY `BranchID` (`BranchID`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`StaffID`, `Name`, `Age`, `DateOfBirth`, `Address`, `PostCode`, `PhoneNo`, `BranchID`) VALUES
(1, 'John Horner', 51, '1969-04-27', '12 Tullymore Cottage', 'BT48 7Y5', 789538578, 1),
(2, 'Jenny Stewart', 36, '1986-07-14', '38 Birch Hill', 'BT42 9UJ', 795326864, 3),
(3, 'Lisa Monroe', 42, '1978-02-13', '91 Larkin Drive', 'BT48 4EW', 732648907, 4),
(4, 'Michael Lynch', 30, '1992-04-01', '482 Chapel Hill', 'BT48 73Y', 783524813, 1),
(5, 'Harry Hawkins', 49, '1972-01-31', '12 Loughway Park', 'BT49 7UT', 732648194, 2),
(6, 'Jill Murray', 43, '1979-10-19', '102 Borough Fields', 'BT42 4RT', 798642175, 3);

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

DROP TABLE IF EXISTS `stock`;
CREATE TABLE IF NOT EXISTS `stock` (
  `CarID` int(5) DEFAULT NULL,
  `BranchID` int(5) DEFAULT NULL,
  `Quantity` int(11) DEFAULT NULL,
  KEY `CarID` (`CarID`),
  KEY `BranchID` (`BranchID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`CarID`, `BranchID`, `Quantity`) VALUES
(2, 4, 10),
(5, 1, 7),
(1, 3, 12),
(6, 2, 5),
(3, 1, 6),
(4, 4, 2);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
