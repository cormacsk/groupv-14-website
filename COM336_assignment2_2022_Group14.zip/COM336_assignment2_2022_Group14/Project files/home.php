<?php
session_start();
include 'databaseconnect.php';

 ?>

<!DOCTYPE html>
<html>
    <header>
        <title>Mercedes Website-Welcome</title>
        <link href="css/style.css" rel="stylesheet" type="text/css" />
        <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Nanum+Gothic&display=swap" rel="stylesheet">
    </header>
    <body>
        <!-- Header -->
        <section class="Top">
            <div class="slogan">

              <?php //Logo for the website ?>
             <img src="images/Logo.jpg" alt="logo" class="logo">
             <h2>The Best or Nothing</h2>
             <?php
                //Checks if user has logged/registered, updates navigation, allows logged user to check account
                if (isset($_SESSION["name"])) {

                  ?>
                  <h3><a href = 'account.php'>Account page</a></h3>
                <?php
                } else {
                  ?>
                  <h3><a href="register.html">Register</a></h3>
                  <h3><a href="login.html">Login</a></h3>
              <?php
                }
                ?>

            </div>
            <?php //Navigate to different car types ?>
            <ul id="menu">
                <li><a href="home.php"><strong>Welcome</strong></a></li>
                <li><a href="">Models</a><ul>
                    <li><a href="coupe.php">Coupe</a></li>
                    <li><a href="suv.php">SUV</a></li>
                    <li><a href="sports.php">Sports</a></li>
                </ul></li>
                <li><a href="contact.html">Contact</a></li>
            </ul>

        </section>
        <!-- Main -->
        <section class="main">

        </section>
        <!-- Footer -->
        <footer>All Rights Reserved Mercedes-Benz &copy 2022</footer>
    </body>
</html>
