<?php include 'cardisplay.php'; ?>


<!DOCTYPE html>
<html>
    <header>
        <title>Mercedes Website-Coupe</title>
        <link href="css/style.css" rel="stylesheet" type="text/css" />
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Nanum+Gothic&display=swap" rel="stylesheet">
    </header>
    <body>
        <!-- Header -->
        <section class="Top">
            <div class="slogan">
             <img src="images/Logo.jpg" alt="logo" class="logo">
             <h2>The Best or Nothing</h2>
             <?php
             //Checks if user has logged/registered, updates navigation, allows logged user to check account
                if (isset($_SESSION["name"])) { ?>
                  <h3><a href = 'account.php'>Account page</a></h3>
                <?php
                } else {
                  ?>
                  <h3><a href="register.html">Register</a></h3>
                  <h3><a href="login.html">Login</a></h3>
              <?php
                }
                ?>
            </div>
            <?php //Navigate to different car types ?>
            <ul id="menu">
                <li><a href="home.php">Welcome</a></li>
                <li><a href="">Models</a><ul>
                    <li><a href="coupe.php"><strong>Coupe</strong></a></li>
                    <li><a href="suv.php">SUV</a></li>
                    <li><a href="sports.php">Sports</a></li>
                </ul></li>
                <li><a href="contact.html">Contact</a></li>
            </ul>

        </section>
        <!-- Main -->
        <section class="main">
            <h1>Coupe Cars</h1>
            <section class="cars">
              <?php
                //Query for cars of type coupe
        				$query = "SELECT * FROM cars WHERE TYPE = 'coupe' ORDER BY CarID ASC";
        				$result = mysqli_query($connect, $query);

        				if(mysqli_num_rows($result) > 0)	{
                  //Displays information from the database for coupe
        					while($row = mysqli_fetch_array($result))	{
        				?>
                <form method="post" action="coupe.php?action=add&id=<?php echo $row["CarID"]; ?>">
                <h2><?php echo $row["CarName"]; ?></h2>
                <img src="images/<?php echo $row["image"]; ?>">
                <ul>
                    <li>Engine Type: <?php echo $row["EngineSize"]; ?></li>
                    <li>Miles: 15,000</li>
                    <li>Year: <?php echo $row["Year"]; ?></li>
                    <li>Fuel: Petrol</li>
                    <li>Handling: Manual</li>
                    <li>Price: £<?php echo $row["Price"]; ?></li>


                    <?php
                    //Displays the stock levels for each car, changes when a car is ordered or cancelled
                    $stockque = "SELECT Quantity FROM stock WHERE CarID = '" .$row["CarID"]. "'";
          					$res2 = mysqli_query($connect, $stockque) or die(mysqli_error($connect));

          					while($stockrow = mysqli_fetch_assoc($res2)){
          						$quantity = $stockrow['Quantity'];
          					}?>

                    <li>Stock: <?php echo $quantity; ?></li>

                </ul>
                <?php //Adds the following info to cardisplay to send to cart ?>
                <input type="text" name="quantity" value="1" class="form-control" />
                <input type="hidden" name="hidden_image" value="<?php echo $row["image"]; ?>" />
                <input type="hidden" name="hidden_name" value="<?php echo $row["CarName"]; ?>" />
						    <input type="hidden" name="hidden_price" value="<?php echo $row["Price"]; ?>" />
						    <input type="submit" name="add_to_cart" style="margin-top:5px;" class="btn btn-primary" value="Add to Cart" />
                <?php //Button to go to review page for a certain car  ?>
                <button><a href = "review.php?&id=<?php echo $row["CarID"]; ?>">Reviews</a></button>
                </form>
                <?php
                  }
                }
                ?>
            </section>

        </section>
        <?php include 'cart.php';?>
        <!-- Footer -->
        <footer>All Rights Reserved Mercedes-Benz &copy 2022</footer>
    </body>
</html>
