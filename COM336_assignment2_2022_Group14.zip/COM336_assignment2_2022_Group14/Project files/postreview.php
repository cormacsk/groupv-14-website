<?php
session_start();
include 'databaseconnect.php';

//Check if the button has been pressed
if(isset($_POST["send"])) {
    //Checks if there is info in the textboxes
    if ( isset($_POST['rating']) && isset($_POST['comment']) ) {
      //Checks if rating is between 0 and 5
       if ($_POST['rating'] > 0 && $_POST['rating'] <= 5){

              //Obtains the customer query
              $custquery = "SELECT CustomerID FROM customer WHERE name = '" .$_SESSION['name']. "' ";
              $result = mysqli_query($connect, $custquery) or die(mysqli_error($connect));

              while($row = mysqli_fetch_assoc($result)){
                $custid = (int) $row['CustomerID'];
              }

              //Obtains the carid
              $carquery = "SELECT CarID FROM cars WHERE CarID ='" .$_GET["id"]. "' ";
              $result = mysqli_query($connect, $carquery) or die(mysqli_error($connect));

              while($row = mysqli_fetch_assoc($result)){
                $carid = $row['CarID'];
              }

              //Transfers values from texboxes
              $rating = $_POST['rating'];
              $comment = $_POST['comment'];

              //Inserts info into review table
              $sql = "INSERT INTO review (CustomerID, CarID, rating, comment) VALUES ('$custid', '$carid', '$rating', '$comment' )";
              $res = mysqli_query($connect, $sql);
              if($res) {
                echo '<script>alert("Review has been posted")</script>';
                	header("Location: review.php?id= $carid");
              }

      } else {
              echo '<script>alert("Rating must be between 1 and 5")</script>';
      }
    }

}
?>
