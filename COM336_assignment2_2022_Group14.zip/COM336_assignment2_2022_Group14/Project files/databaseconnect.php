<?php

$connect = mysqli_connect("assignment2.ca2ymezj9uqq.us-east-1.rds.amazonaws.com", "COM336Group14", "Iwilldeletethisafter20", "Assignment2");

?>
