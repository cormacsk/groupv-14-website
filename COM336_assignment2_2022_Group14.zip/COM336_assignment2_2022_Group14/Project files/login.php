<?php

session_start();

// database connection
include 'databaseconnect.php';


if (mysqli_connect_errno()) { // if connection fails, show error message and exit
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  exit();
}
// if connection is successful, sign up new users
// check if user exists already
else {
  //echo "Successfully connected to your database...";
  if(isset($_POST['submit'])){
    echo "Form submitted .. <br /><br />";
    SignUp();
  }
}

function SignUp() {
  global $connect;
  // use a SELECT query to check whether user exists already
  if(isset($_POST['name'])) { //check whether the the field 'user' is it empty or have some value

    $sql="SELECT * FROM customer WHERE Name = '$_POST[name]' AND password = '$_POST[password]'";
    $res = mysqli_query($connect, $sql) or die(mysqli_error($connect));
    // check the number of records returned by the SELECT query, if zero: there is no match
    //of this user found in the database, i.e. a new user
    if(mysqli_num_rows($res) ==1) {
      echo "Welcome back '$_POST[name]'";
      header("Location: home.php");
      $_SESSION["name"] = "$_POST[name]";

    } else { // if a match is found, user exists already and no need for register again
      echo '<script>alert("You have not registered yet")</script>';
      header("Location: login.html");

    }
  }
}
?>
