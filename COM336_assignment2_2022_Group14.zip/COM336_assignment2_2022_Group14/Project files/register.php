<?php
session_start();

// database connection
include 'databaseconnect.php';


if (mysqli_connect_errno()) { // if connection fails, show error message and exit
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  exit();
}
// if connection is successful, sign up new users
// check if user exists already
else {
  //echo "Successfully connected to your database...";
  if(isset($_POST['submit'])){
    echo "Form submitted .. <br /><br />";
    SignUp();
  }
}

function NewUser() {
  // sign up a new user
  global $mysqlconn;
  $fullname = $_POST['name'];
  $age = $_POST['age'];
  $dob = $_POST['dob'];
  $address = $_POST['address'];
  $postcode = $_POST['postcode'];
  $phoneNo = $_POST['phoneNo'];
  $password = $_POST['password'];
  $query = "INSERT INTO customer (Name,Age,DateOfBirth,Address,PostCode,PhoneNo,Password) VALUES
  ('$fullname','$age','$dob','$address','$postcode','$phoneNo','$password')";

  $data = mysqli_query ($connect, $query) or die(mysqli_error($connect));
  if($data) {
    echo "<br>Thank you for signing up ... your registration is successfully completed";
    $_SESSION["name"] = "$_POST[name]";
    header("Location: home.php");
  }
}

function SignUp() {
  global $connect;
  // use a SELECT query to check whether user exists already
  if(isset($_POST['name'])) { //check whether the the field 'user' is it empty or have some value

    $sql="SELECT * FROM customer WHERE Name = '$_POST[name]' AND Password = '$_POST[password]'";
    $res = mysqli_query($connect, $sql) or die(mysqli_error($connect));
    // check the number of records returned by the SELECT query, if zero: there is no match
    //of this user found in the database, i.e. a new user
    if(mysqli_num_rows($res) ==0) {
      newuser();
    } else { // if a match is found, user exists already and no need for register again
      echo '<script>alert("You have already registered")</script>';
      header("Location: register.html");
    }
  }
}
?>
