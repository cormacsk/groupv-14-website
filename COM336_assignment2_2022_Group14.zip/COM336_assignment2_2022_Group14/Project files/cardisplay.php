<?php
session_start();
include 'databaseconnect.php';

//If a user is not logged they can't add to cart
if (!isset($_SESSION["name"])){
echo '<script>alert("Please register or login to order")</script>';
} else if(isset($_POST["add_to_cart"])) {
		global $connect;

		//Checks if user has already ordered
		$sql="SELECT orders.CustomerID FROM orders, customer WHERE orders.CustomerID = customer.CustomerID and name = '" .$_SESSION['name']. "'  ";
		$res = mysqli_query($connect, $sql) or die(mysqli_error($connect));

		//Gets quantity for the car depending on the id
		$query = "SELECT Quantity FROM stock  WHERE CarID = '" .$_GET["id"]. "'";
		$resultin = mysqli_query($connect, $query) or die(mysqli_error($connect));

		while($stockrow = mysqli_fetch_assoc($resultin)){
			$quantity = $stockrow['Quantity'];
		}

		if(mysqli_num_rows($res) == 1) {
			echo '<script>alert("Cannot add to cart, a car already has been ordered")</script>';
		} else if ($quantity > 0) {
			//Makes sure the quantity of the car is greater than 0;
			if(isset($_SESSION["shopping_cart"]))	{

					$item_array_id = array_column($_SESSION["shopping_cart"], "item_id");

					if(!in_array($_GET["id"], $item_array_id) && count($_SESSION["shopping_cart"]) == 0) {
						//Inputs info from car into array
						$count = count($_SESSION["shopping_cart"]);
						$item_array = array(
							'item_id'			=>	$_GET["id"],
							'item_image'   => $_POST["hidden_image"],
							'item_name'			=>	$_POST["hidden_name"],
							'item_price'		=>	$_POST["hidden_price"],
							'item_quantity'		=>	$_POST["quantity"]);

						$_SESSION["shopping_cart"][$count] = $item_array;
					}	else if (in_array($_GET["id"], $item_array_id)) {
						echo '<script>alert("Item already in cart")</script>';
					} else {
						echo '<script>alert("You can only order one car")</script>';
					}
				}	else {
					$item_array = array(
						'item_id'			=>	$_GET["id"],
						'item_image'   => $_GET["hidden_image"],
						'item_name'			=>	$_POST["hidden_name"],
						'item_price'		=>	$_POST["hidden_price"],
						'item_quantity'		=>	$_POST["quantity"] );

					$_SESSION["shopping_cart"][0] = $item_array;
				}

		} else {
			echo '<script>alert("Cannot add to cart. No more left in stock")</script>';
		}

}

if(isset($_GET["action"])) {
	//Checks action, if delete removes car
	if($_GET["action"] == "delete")	{

		foreach($_SESSION["shopping_cart"] as $keys => $values)	{

			if($values["item_id"] == $_GET["id"])	{
				unset($_SESSION["shopping_cart"][$keys]);
				echo '<script>alert("Item removed from cart")</script>';
				echo '<script>window.location="coupe.php"</script>';
			}
		}
	}
	//if order, orders a car
	if ($_GET["action"] == "order") {
		global $connect;
			foreach($_SESSION["shopping_cart"] as $keys => $values)	{
				if($values["item_id"] == $_GET["id"])	{
					//Gets carid and customerid
				  $carid = $values["item_id"];
					$custquery = "SELECT CustomerID FROM customer WHERE name = '" .$_SESSION['name']. "' ";
					$result = mysqli_query($connect, $custquery) or die(mysqli_error($connect));

					while($row = mysqli_fetch_assoc($result)){
						$custid = (int) $row['CustomerID'];
					}

					//Inserts values into orders table
				  $quantity = $values["item_quantity"];
				  $query = "INSERT INTO orders (CustomerID, CarID, Quantity) VALUES ('$custid', '$carid', '$quantity')";

					$data = mysqli_query ($connect, $query) or die(mysqli_error($connect));
					if($data) {
						//If true updates stock
						echo '<script>alert("Thank you for the order")</script>';
						$stockque = "UPDATE stock SET Quantity = Quantity - '1' WHERE CarID = '" .$carid. "'";
						$res2 = mysqli_query($connect, $stockque) or die(mysqli_error($connect));

						unset($_SESSION["shopping_cart"][$keys]);
						header("Location: account.php");
					}
				}
			}
	}
	//If cancel, cancels the order
	if($_GET["action"] == "cancel"){

		//Deletes the order
		$query = "DELETE FROM orders WHERE CustomerID IN
		(SELECT DISTINCT CustomerID FROM (SELECT * FROM customer) AS something
		WHERE '" .$_SESSION['name']. "' = name) ";

		$data = mysqli_query ($connect, $query) or die(mysqli_error($connect));
		if($data) {
			//Updates the stock by increasing
			$stockque = "UPDATE stock SET Quantity = Quantity + '1' WHERE CarID = '" .$_GET["id"]. "'";
			$res2 = mysqli_query($connect, $stockque) or die(mysqli_error($connect));
			echo '<script>alert("Your order has been cancelled")</script>';
			header("Location: account.php");
		}
	}




}

?>
