<?php

session_start();

include 'databaseconnect.php';

if ( isset( $_GET["action"] ) and $_GET["action"] == "logout" ) {
  logout();
}

function logout() {
  unset($_SESSION["name"]);
  header( "Location: home.php" );
}
 ?>

 <!DOCTYPE html>
 <html>
     <header>
         <title>Mercedes Website-Welcome</title>
         <link href="css/style.css" rel="stylesheet" type="text/css" />
         <link rel="preconnect" href="https://fonts.googleapis.com">
     <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
     <link href="https://fonts.googleapis.com/css2?family=Nanum+Gothic&display=swap" rel="stylesheet">
     </header>
     <body>
         <!-- Header -->
         <section class="Top">
             <div class="slogan">
              <img src="images/Logo.jpg" alt="logo" class="logo">
              <h2>The Best or Nothing</h2>

             </div>
             <ul id="menu">
                 <li><a href="home.php"><strong>Welcome</strong></a></li>
                 <li><a href="">Models</a><ul>
                     <li><a href="coupe.php">Coupe</a></li>
                     <li><a href="suv.php">SUV</a></li>
                     <li><a href="sports.php">Sports</a></li>
                 </ul></li>
                 <li><a href="contact.html">Contact</a></li>
             </ul>

         </section>
         <!-- Main -->
         <section class="main">
          <div class = "accinfo">

            <img src="images/profile-pic.jpg" alt="profile" class="profile">

              <h3>  <?php echo $_SESSION["name"]; ?> </h3>
              <?php //If shopping cart is not empty display the following ?>
               <?php
               if(!empty($_SESSION["shopping_cart"]))	{
                 ?>
                 <h2> Order Details </h2>
                 <?php
                 $total = 0;
                 //Goes through shopping cart, name, price, image etc
                 foreach($_SESSION["shopping_cart"] as $keys => $values)	{
               ?>
                 <img src="images/<?php echo $values["item_image"]; ?>">
                 <h4> Name of Car: <?php echo $values["item_name"]; ?></h4>
                 <h4> Price of order: £ <?php  echo number_format( $values["item_price"]); ?> </h4>
                 <?php //Action links for delete from cart and cancel ?>
                 <a href="coupe.php?action=delete&id=<?php echo $values["item_id"]; ?>"><span class="text-dark">Remove</span></a>
                 <p> <a href="cardisplay.php?action=order&id=<?php echo $values["item_id"]; ?>" > Order Car </a> </p>

               <?php
                 }
               ?>

               <?php
               }

               global $connect;
               //Checks if user has already ordered
               $sql="SELECT orders.CustomerID FROM orders, customer WHERE orders.CustomerID = customer.CustomerID AND name = '" .$_SESSION['name']. "' ";
               $res = mysqli_query($connect, $sql) or die(mysqli_error($connect));

               if(mysqli_num_rows($res) == 1) {
                 // If so displays order details ?>
                  <h2>Current Order</h2>

                 <?php
                $orderquery = "SELECT * FROM cars, orders, customer WHERE customer.CustomerID = orders.CustomerID AND orders.CarID = cars.CarID AND name = '" .$_SESSION['name']. "' ; ";
                $result = mysqli_query($connect, $orderquery) or die(mysqli_error($connect));

                while($row = mysqli_fetch_assoc($result)){
                  ?>
                  <img src="images/<?php echo $row["image"]; ?>">
                  <h4> Name of Car: <?php echo $row["CarName"]; ?></h4>
                  <h4> Price of order: £ <?php echo $row["Price"]; ?> </h4>

                  <?php //Cancels order ?>
                  <p> <a href="cardisplay.php?action=cancel&id=<?php echo $row["CarID"]; ?>" > Cancel Order </a> </p>
                <?php
                }

              }
                ?>
            <?php // Allows user to logout ?>
             <p> <a href="account.php?action=logout" > Logout </a> </p>

          </div>

         </section>
         <!-- Footer -->
         <footer>All Rights Reserved Mercedes-Benz &copy 2022</footer>
     </body>
 </html>
