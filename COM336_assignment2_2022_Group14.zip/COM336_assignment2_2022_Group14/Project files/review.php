<?php
include 'postreview.php';

?>


<!DOCTYPE html>
<html>
    <header>
        <title>Mercedes Website-Welcome</title>
        <link href="css/style.css" rel="stylesheet" type="text/css" />
        <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Nanum+Gothic&display=swap" rel="stylesheet">
    </header>
    <body>
        <!-- Header -->
        <section class="Top">
            <div class="slogan">
             <img src="images/Logo.jpg" alt="logo" class="logo">
             <h2>The Best or Nothing</h2>
             <?php
             //Checks if user has logged/registered, updates navigation, allows logged user to check account
                if (isset($_SESSION["name"])) {  ?>
                  <h3><a href = 'account.php'>Account page</a></h3>
                <?php
                } else {
                  ?>
                  <h3><a href="register.html">Register</a></h3>
                  <h3><a href="login.html">Login</a></h3>
              <?php
                }
                ?>

            </div>
            <ul id="menu">
                <li><a href="home.php"><strong>Welcome</strong></a></li>
                <li><a href="">Models</a><ul>
                    <li><a href="coupe.php">Coupe</a></li>
                    <li><a href="suv.php">SUV</a></li>
                    <li><a href="sports.php">Sports</a></li>
                </ul></li>
                <li><a href="contact.html">Contact</a></li>
            </ul>

        </section>
        <!-- Main -->
        <section class="cars">

          <?php
          global $connect;
          //Gets the id for the car whose review button was clicked
          $carid = (isset($_GET['id']) ? $_GET['id'] : null);

          //Query to display information based on the carid
      	  $sql="SELECT * FROM cars WHERE CarID = '" . $carid. "' ";
      	  $res = mysqli_query($connect, $sql) or die(mysqli_error($connect));

          while($row = mysqli_fetch_assoc($res)){?>
            <form>
            <h2><?php echo $row["CarName"]; ?></h2>
            <img src="images/<?php echo $row["image"]; ?>">
            <ul>
                <li>Engine Type: <?php echo $row["EngineSize"]; ?></li>
                <li>Miles: 15,000</li>
                <li>Year: <?php echo $row["Year"]; ?></li>
                <li>Fuel: Petrol</li>
                <li>Handling: Manual</li>
                <li>Price: £<?php echo $row["Price"]; ?></li>

            </ul>
          </form>
            <?php
					}

          //Selects all the information based on the carid
          $sql = "SELECT * FROM review WHERE CarID = '" . $carid. "'";
          $res = mysqli_query($connect, $sql);
          //Number of reviews for a certain car of that id
          $num_messages = mysqli_num_rows($res);

          ?>

          <section = "cars">
            <?php //User can type and post a review  ?>
            <h1>Post a Review</h1>

            <form id = "review" method = "post" action="review.php?action=post&id=<?php echo $carid ?>">
            Rating: <input type="number" name="rating"  size="10">
            <br><br>
            Comment: <br> <textarea name="comment" cols="40" rows="15">  </textarea>
            <br><br>
            <button type="submit" name="send" value="submit">Post</button>

            <h2>Reviews</h2>
            <i>There are a total of <?php echo $num_messages ?> posts on this page.</i>
            <br><br><hr>

            <?php
            if(mysqli_num_rows($res) > 0)	{
              // Loop over all the reviews and print them out.
              while( $row = mysqli_fetch_assoc($res) ) { ?>

                 <h2>Rating: <?php echo $row['Rating'];  ?> /5 </h2>
                 <p> Comment: <?php echo  $row['Comment']; ?>  </p>

             <?php

              }
            }

            ?>
          </form>

          </section>

        </section>


        <!-- Footer -->
        <footer>All Rights Reserved Mercedes-Benz &copy 2022</footer>
    </body>
</html>
